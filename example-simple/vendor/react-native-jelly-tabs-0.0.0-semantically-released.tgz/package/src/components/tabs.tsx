import { TabItem } from "./tab-item";
import {
    DEFAULT_TAB_BAR_COLORS,
    DEFAULT_TAB_BAR_OPACITY,
    resolveTabBarConfig,
} from "../constants";
import type { TabsProps } from "../types";
import { usePillJelly } from "../hooks/use-pill-jelly";
import { PillMaskedView } from "./pill-masked-view";
import { TouchFeedback } from "./touch-feedback";
import { cloneElement, useCallback, useMemo, useRef } from "react";
import { Platform, StyleSheet, View } from "react-native";
import { GestureDetector } from "react-native-gesture-handler";
import Animated from "react-native-reanimated";

export const JellyTabs = ({
    backdrop,
    colors,
    config,
    displayScale = 1,
    items,
    onTabChange,
    opacity,
    recording = false,
    selectedBackdrop,
    touchFeedbackColor,
    touchFeedbackEnabled = true,
    touchFeedbackOpacity,
    touchFeedbackScale,
}: TabsProps) => {
    const trackRef = useRef<View>(null);
    const resolvedConfig = useMemo(() => resolveTabBarConfig(config), [config]);
    const resolvedColors = {
        ...DEFAULT_TAB_BAR_COLORS,
        ...colors,
    };
    const resolvedOpacity = {
        ...DEFAULT_TAB_BAR_OPACITY,
        ...opacity,
    };
    const normalizeOpacity = (value: number) => Math.min(Math.max(value, 0), 1);
    const activeContentOpacity = normalizeOpacity(
        resolvedOpacity.activeContent,
    );
    const inactiveContentOpacity = normalizeOpacity(
        resolvedOpacity.inactiveContent,
    );
    const selectedSurfaceOpacity = normalizeOpacity(
        resolvedOpacity.selectedSurface,
    );
    const surfaceOpacity = normalizeOpacity(resolvedOpacity.surface);
    const resolvedTouchFeedbackOpacity =
        touchFeedbackOpacity ?? resolvedConfig.distortion.touchFeedback.opacity;
    const resolvedTouchFeedbackScale =
        touchFeedbackScale ?? resolvedConfig.distortion.touchFeedback.scale;
    const resolvedTouchFeedbackColor =
        touchFeedbackColor ?? resolvedColors.selectedSurface;
    const maskOverscanX = resolvedConfig.layout.maskOverscanX * displayScale;
    const maskOverscanY = resolvedConfig.layout.maskOverscanY * displayScale;
    const trackInset = resolvedConfig.layout.trackInset * displayScale;
    const trackHeight = resolvedConfig.layout.trackHeight * displayScale;
    const itemHeight = resolvedConfig.layout.itemHeight * displayScale;
    const iconSize = resolvedConfig.layout.iconSize * displayScale;
    const normalizedTouchFeedbackOpacity = Math.min(
        Math.max(resolvedTouchFeedbackOpacity, 0),
        1,
    );
    const normalizedTouchFeedbackScale = Math.max(
        resolvedTouchFeedbackScale,
        0,
    );
    const touchFeedbackRadius =
        resolvedConfig.distortion.touchFeedback.radius *
        normalizedTouchFeedbackScale *
        displayScale;
    const touchFeedbackDiameter = touchFeedbackRadius * 2;
    const touchFeedbackMiddleOpacity =
        normalizedTouchFeedbackOpacity *
        resolvedConfig.distortion.touchFeedback.middleOpacityRatio;

    const handleTabChange = useCallback(
        (index: number) => {
            const item = items[index];
            if (item) {
                onTabChange?.({ index, item });
            }
        },
        [items, onTabChange],
    );

    const tabs = items.map((item) => (
        <TabItem
            activeColor={resolvedColors.activeContent}
            activeOpacity={activeContentOpacity}
            activeIcon={item.activeIcon}
            colors={resolvedColors}
            displayScale={displayScale}
            iconSize={iconSize}
            inactiveIcon={item.inactiveIcon}
            inactiveColor={resolvedColors.inactiveContent}
            inactiveOpacity={inactiveContentOpacity}
            itemHeight={itemHeight}
            key={item.key}
            text={item.label}
        />
    ));
    const tabCount = tabs.length;
    const {
        activeItemStyle,
        activePillClipStyle,
        activePillMaskStyle,
        gesture,
        panelStyle,
        pillClipStyle,
        pillMaskStyle,
        pressedStyle,
        selectedTouchFeedbackStyle,
        setTrackWidth,
        setWebTrackPageX,
        tabbarStyle,
        touchFeedbackStyle,
    } = usePillJelly(
        tabCount,
        resolvedConfig,
        recording,
        displayScale,
        touchFeedbackRadius,
        onTabChange ? handleTabChange : undefined,
    );

    return (
        <GestureDetector gesture={gesture}>
            <Animated.View
                collapsable={false}
                style={[
                    styles.pressWrapper,
                    { height: trackHeight },
                    pressedStyle,
                ]}
            >
                <Animated.View
                    collapsable={false}
                    pointerEvents="box-only"
                    ref={trackRef}
                    testID="tabs-drag-surface"
                    style={[styles.track, { height: trackHeight }, tabbarStyle]}
                    onLayout={(event) => {
                        setTrackWidth(event.nativeEvent.layout.width);
                        if (Platform.OS === "web") {
                            trackRef.current?.measureInWindow((x) =>
                                setWebTrackPageX(x),
                            );
                        }
                    }}
                >
                    <Animated.View
                        pointerEvents="none"
                        style={[styles.panel, panelStyle]}
                    >
                        <View
                            style={[
                                styles.surfaceClip,
                                {
                                    borderRadius: trackHeight / 2,
                                },
                            ]}
                        >
                            {backdrop}
                            <View
                                style={[
                                    styles.surface,
                                    {
                                        backgroundColor: resolvedColors.surface,
                                        opacity: surfaceOpacity,
                                    },
                                ]}
                            />
                        </View>

                        {touchFeedbackEnabled && (
                            <View
                                style={[
                                    styles.touchFeedbackClip,
                                    { borderRadius: trackHeight / 2 },
                                ]}
                            >
                                <TouchFeedback
                                    animatedStyle={touchFeedbackStyle}
                                    centerOpacity={
                                        normalizedTouchFeedbackOpacity
                                    }
                                    color={resolvedTouchFeedbackColor}
                                    diameter={touchFeedbackDiameter}
                                    gradientId="tabbar-touch-feedback"
                                    middleOpacity={touchFeedbackMiddleOpacity}
                                    radius={touchFeedbackRadius}
                                />
                            </View>
                        )}

                        <View
                            style={[
                                styles.tabsRow,
                                { paddingHorizontal: trackInset },
                            ]}
                        >
                            {tabs.map((tab, index) =>
                                cloneElement(tab, {
                                    key: `inactive-${index}`,
                                }),
                            )}
                        </View>

                        <View
                            style={[
                                styles.maskOverscan,
                                {
                                    bottom: -maskOverscanY,
                                    left: -maskOverscanX,
                                    right: -maskOverscanX,
                                    top: -maskOverscanY,
                                },
                            ]}
                        >
                            <PillMaskedView
                                animatedStyle={pillMaskStyle}
                                clipStyle={pillClipStyle}
                                height={itemHeight}
                                left={maskOverscanX + trackInset}
                                top={maskOverscanY + trackInset}
                            >
                                <View style={styles.selectedSurface}>
                                    {selectedBackdrop}
                                    <View
                                        style={[
                                            StyleSheet.absoluteFill,
                                            {
                                                backgroundColor:
                                                    resolvedColors.selectedSurface,
                                                opacity: selectedSurfaceOpacity,
                                            },
                                        ]}
                                    />
                                </View>
                                {touchFeedbackEnabled && (
                                    <TouchFeedback
                                        animatedStyle={
                                            selectedTouchFeedbackStyle
                                        }
                                        centerOpacity={
                                            normalizedTouchFeedbackOpacity
                                        }
                                        color={resolvedTouchFeedbackColor}
                                        diameter={touchFeedbackDiameter}
                                        gradientId="selected-tab-touch-feedback"
                                        middleOpacity={
                                            touchFeedbackMiddleOpacity
                                        }
                                        offsetX={maskOverscanX}
                                        offsetY={maskOverscanY}
                                        radius={touchFeedbackRadius}
                                    />
                                )}
                            </PillMaskedView>

                            <PillMaskedView
                                animatedStyle={activePillMaskStyle}
                                clipStyle={activePillClipStyle}
                                height={itemHeight}
                                left={maskOverscanX + trackInset}
                                top={maskOverscanY + trackInset}
                            >
                                <View
                                    style={[
                                        styles.selectedTabsRow,
                                        {
                                            height: itemHeight,
                                            left: maskOverscanX + trackInset,
                                            right: maskOverscanX + trackInset,
                                            top: maskOverscanY + trackInset,
                                        },
                                    ]}
                                >
                                    {tabs.map((tab, index) =>
                                        cloneElement(tab, {
                                            animatedStyle: activeItemStyle,
                                            isActive: true,
                                            key: `active-${index}`,
                                        }),
                                    )}
                                </View>
                            </PillMaskedView>
                        </View>
                    </Animated.View>
                </Animated.View>
            </Animated.View>
        </GestureDetector>
    );
};

const styles = StyleSheet.create({
    pressWrapper: {
        width: "100%",
    },
    track: {
        position: "relative",
        width: "100%",
        overflow: "visible",
    },
    panel: {
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        top: 0,
    },
    surface: {
        position: "absolute",
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
    },
    surfaceClip: {
        bottom: 0,
        left: 0,
        position: "absolute",
        right: 0,
        top: 0,
        overflow: "hidden",
    },
    touchFeedbackClip: {
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        top: 0,
        overflow: "hidden",
    },
    tabsRow: {
        position: "absolute",
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        flexDirection: "row",
        alignItems: "center",
    },
    maskOverscan: {
        position: "absolute",
        zIndex: 2,
    },
    selectedSurface: {
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        top: 0,
    },
    selectedTabsRow: {
        position: "absolute",
        flexDirection: "row",
        alignItems: "center",
        zIndex: 1,
    },
});
